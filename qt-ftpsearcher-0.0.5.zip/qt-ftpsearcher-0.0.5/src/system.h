#ifndef SYSTEM_H
#define SYSTEM_H

#define VERSION "0.0.5"

#endif
