#include "../system.h"
#include <QCoreApplication>
#include <QSettings>
#include "func.h"

#ifdef Q_WS_WIN
	QString path = QDir::rootPath()+"Program Files/Qt-FtpSearcher/html";
	QSettings settings(QDir::rootPath()+"Program Files/Qt-FtpSearcher/qt-ftpsearcher-webui.ini",
                           QSettings::IniFormat);
#else
        QString path = QDir::rootPath()+"usr/share/qt-ftpsearcher/html";
        QSettings settings(QDir::rootPath()+"etc/qt-ftpsearcher-webui.conf",
                           QSettings::IniFormat);
#endif
        QString log_path = QDir::tempPath()+"/qt-ftpsearcher/";
        QString def_path = path;

        int main(int argc, char ** argv)
{
    QCoreApplication app(argc,argv);

    QByteArray help = "qt-ftpsearcher-webui (Qt Ftp Searcher Web UI) -- program written on C++ and Qt4.\r\n"
            "It also uses FastCGI: http://www.fastcgi.com/\r\n"
            "    -h, -help  show this help\r\n"
            "    -v         version information\r\n";

    QByteArray vers = "Version: "+QByteArray(VERSION)+
            "\r\nThis program uses Qt Open Source Edition version "
            +QByteArray(QT_VERSION_STR)+
            "\r\n2009 (c) Boris Pek (aka \\\\Tehnick)\r\n";

    QString arg;
    for(int i=0; i<argc; ++i){
        arg = QString(argv[i]).toLower();
        if(arg=="-h"||arg=="-help"||arg=="--help"){
            qDebug(help.constData());
            return 0;
        }
        if(arg=="-v"){
            qDebug(vers.constData());
            return 0;
        }
    }
    help.~QByteArray();
    vers.~QByteArray();
    arg.~QString();

    def_path = settings.value("PathToHtmlFiles",def_path).toString();
    log_path = settings.value("PathToLogFiles",log_path).toString();
    if(def_path.endsWith("/")) def_path.remove(def_path.size()-1,1);

    QSqlDatabase db = QSqlDatabase::addDatabase(
            settings.value("DatabaseType","QMYSQL").toString());
    QString tmp = settings.value("DatabaseName").toString();
    if(!tmp.isEmpty()) db.setDatabaseName(tmp);
    else save_error_log("Warning: DatabaseName is empty.\r\n");
    tmp = settings.value("UserName").toString();
    if(!tmp.isEmpty()) db.setUserName(tmp);
    tmp = settings.value("Password").toString();
    if(!tmp.isEmpty()) db.setPassword(tmp);
    db.setHostName(settings.value("HostName","127.0.0.1").toString());
    db.setPort(settings.value("Port",3306).toInt());
    db.open();
    qApp->processEvents();

    int num=0;
    while(FCGI_Accept() >= 0){
        ++num;
        char *content=NULL;
        char *request_method=getenv("REQUEST_METHOD");
        if(request_method==NULL) continue;
        if(strcmp(request_method,"GET")==0){
            content=getenv("QUERY_STRING");
        }
        else if(strcmp(request_method,"POST")==0){
            char *endptr;
            unsigned int contentlength;
            const char *clen = getenv("CONTENT_LENGTH");
            contentlength=strtol(clen,&endptr,10);
            content=new char[contentlength];
            fread(content,contentlength,1,stdin);
            content[contentlength]='\0';
        }else{
            printf("Content-type: text/html\r\n\r\n");
            printf("<center><h2>Unknown REQUEST_METHOD. "
                    "Use only GET or POST !</h2></center>\r\n");
            continue;
        };

        if(fix_some_bug){
            db.close();
        }
        if(!db.isOpen()) if(!db.open()){
            QString error = "Could'n open database "+db.databaseName()+
                    ":\r\n"+db.lastError().text()+"\r\n";
            save_error_log(error);
        }

        QString file = QString(getenv("SCRIPT_NAME")).toLower();
        path = getenv("SCRIPT_FILENAME");

        if(file.endsWith(".css"))
            printf("Content-type: text/css\r\n\r\n");
        else if(file.endsWith(".js"))
            printf("Content-type: text/js\r\n\r\n");
        else if(file.endsWith(".txt"))
            printf("Content-type: text/txt\r\n\r\n");
        else if(file.endsWith(".log"))
            printf("Content-type: text/log\r\n\r\n");
        else if(file.endsWith(".png"))
            printf("Content-type: image/png\r\n\r\n");
        else if(file.endsWith(".gif"))
            printf("Content-type: image/gif\r\n\r\n");
        else if(file.endsWith(".jpg"))
            printf("Content-type: image/jpg\r\n\r\n");
        else if(file.endsWith(".jpeg"))
            printf("Content-type: image/jpeg\r\n\r\n");
        else	printf("Content-type: text/html\r\n\r\n");

        if(file.endsWith("/ftp/")){
            test_path(file);
            ftp_find();
        }
        else if(file.endsWith("/ftp/stat")){
            path.replace("stat","");
            file.replace("stat","");
            test_path(file);
            ftp_stat(content);
        }
        else if(file.endsWith("/ftp/find")){
            path.replace("find","");
            file.replace("find","");
            test_path(file);
            ftp(content);
        }
        else if(file.endsWith("/ftp/num")){
            printf("<center><h2>Current query number = %i</h2></center>",num);
        }
        else if(file.endsWith("/ftp/info")){
            path.replace("info","");
            file.replace("info","");
            test_path(file);
            info();
        }
        else{
            test_path(file);
            index();
        }
        if(strcmp(request_method,"POST")==0) delete[]content;
        save_log();
    }
    db.close();
    return 0;
}

