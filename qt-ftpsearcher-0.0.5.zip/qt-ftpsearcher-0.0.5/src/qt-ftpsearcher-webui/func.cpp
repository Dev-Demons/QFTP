#include "func.h"

bool fix_some_bug = false;

void save_log()
{
    QDir dir; dir.mkdir(log_path);
    QString log;
    QFile file;
    file.setFileName(log_path+QString(getenv("REMOTE_ADDR"))+".log");
    if(file.open(QIODevice::Append | QIODevice::Text)){
        log = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss")+
                "\t\t"+QString(getenv("REQUEST_URI"))+"\r\n";
        file.write(log.toUtf8());
        file.close();
        log.clear();
    }
}

void save_error_log(QString error)
{
    QDir dir; dir.mkdir(log_path);
    QString log;
    QFile file;
    file.setFileName(log_path+"errors.log");
    if(file.open(QIODevice::Append | QIODevice::Text)){
        log = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss")+
                "\r\n"+error+"\r\n";
        file.write(log.toUtf8());
        file.close();
        log.clear();
    }
}

void test_path(QString file)
{
    QDir dir;
    if(!dir.exists(path)){
        if(dir.exists(def_path+file)){
            path=def_path+file;
        }
    }
}

void info()
{
    QFile file(path+"header.html");
    QByteArray out;
    if(file.open(QIODevice::ReadOnly | QIODevice::Text)){
        out = file.readAll();
        file.close();
        out.replace("%title","Environment info");
        printf("%s\r\n",out.data());
    }

    printf("    <div id=\"statText\">\r\n");

    QStringList env = QProcess::systemEnvironment();
    printf("<b>Number of environment variables = %i</b><br>\r\n",env.size());
    for(int i=0;i<env.size();i++)
        printf("%s<br>\r\n",env[i].toUtf8().data());

    printf("    </div>\r\n");

    footer();
}

void index()
{
    QFile file(path);
    if(!file.open(QIODevice::ReadOnly | QIODevice::Text)){
        printf("<center><h2>Page doesn't exist.</h2></center>");
        return;
    }
    QByteArray out = file.readAll();
    file.close();
    printf("%s\n",out.data());
}

void header()
{
    QFile file(path+"header.html");
    if(file.open(QIODevice::ReadOnly | QIODevice::Text)){
        QByteArray out = file.readAll();
        file.close();
        printf("%s\r\n",out.data());
    }
}

void footer()
{
    QFile file(path+"footer.html");
    if(file.open(QIODevice::ReadOnly | QIODevice::Text)){
        QByteArray out = file.readAll();
        file.close();
        printf("%s\r\n",out.data());
    }
}

void ftp(char *content)
{
    QFile file(path+"header.html");
    QByteArray out;
    if(file.open(QIODevice::ReadOnly | QIODevice::Text)){
        out = file.readAll();
        file.close();
        out.replace("%title","Search results");
        out.append("<br>\r\n");
        printf("%s\r\n",out.data());
    }

    QTextCodec *codec = QTextCodec::codecForName("UTF-8");
    QString name = codec->toUnicode(getparam(content,(char*)"n="));
    QString type = codec->toUnicode(getparam(content,(char*)"t="));
    QString min = codec->toUnicode(getparam(content,(char*)"min="));
    QString mint = codec->toUnicode(getparam(content,(char*)"mint="));
    QString max = codec->toUnicode(getparam(content,(char*)"max="));
    QString maxt = codec->toUnicode(getparam(content,(char*)"maxt="));
    QString ip = codec->toUnicode(getparam(content,(char*)"a="));
    QString sort = codec->toUnicode(getparam(content,(char*)"s="));

    QString full;
    QString type_tmp = "file";
    double min_tmp = 0;
    double max_tmp = 0;
    if(mint.isEmpty()) mint = "mb";
    if(maxt.isEmpty()) maxt = "mb";
    if(!min.isEmpty()){
        if(mint=="b")       min_tmp = min.toDouble();
        else if(mint=="kb") min_tmp = min.toDouble()*1024;
        else if(mint=="gb") min_tmp = min.toDouble()*1024*1024*1024;
        else                min_tmp = min.toDouble()*1024*1024;
        if(min_tmp>0)
            full.prepend(QString("AND `%1`>=%2").arg("size").arg(min_tmp));
    }
    if(!max.isEmpty()){
        if(maxt=="b")       max_tmp = max.toDouble();
        else if(maxt=="kb") max_tmp = max.toDouble()*1024;
        else if(maxt=="gb") max_tmp = max.toDouble()*1024*1024*1024;
        else                max_tmp = max.toDouble()*1024*1024;
        if(max_tmp>0)
            full.prepend(QString("AND `%1`<=%2").arg("size").arg(max_tmp));
    }
    if(min_tmp!=0 && min_tmp==max_tmp){
        full = QString("AND `%1`='%2'").arg("size")
                .arg(QString::number(max_tmp,'f',0));
    }
    if(!type.isEmpty()){
        if(type=="f") type_tmp = "file";
        if(type=="d") type_tmp = "path";
    }
    if(!name.isEmpty()){
        QString name_tmp = shadeText(name);
        name_tmp.replace(" ",QString("\%' AND `%1` LIKE '\%").arg(type_tmp));
        full.prepend(QString("AND `%1` LIKE '\%%2\%' ").arg(type_tmp).arg(name_tmp));
    }
    if(!ip.isEmpty()){
        full.prepend(QString("AND `%1`='%2' ").arg("ip").arg(ip));
    }

    int tot=0;
    QSqlQuery query;
    QString query_text = "SELECT COUNT(*) FROM ftp_files ;";
    if(!full.isEmpty()) query_text.replace(";",QString("WHERE %1;").arg(full.mid(3,-1)));
    if(type_tmp=="path") query_text.replace("COUNT(*)","COUNT( DISTINCT `path`,`ip` )");
    if(!query.exec(query_text)){
        QString error = "Unable to do database operation "
                "by following reason:\r\n"+
                query.lastError().text()+"\r\n";
        save_error_log(error);
        printf("<br><center>Please reload this page.</center><br>\r\n");
        fix_some_bug = true;
    }else{
        query.last();
        tot = query.value(0).toInt();
    }

    QByteArray mask =
            "<td>%num</td>\r\n"
            "<td><div class=\"tc\"><a href=\"%urlpath\">ftp://%ip%path/</a></div></td>\r\n"
            "<td><div class=\"tc\">%file</div></td>\r\n"
            "<td><div class=\"tc\"><a href=\"./find?min=%sb&mint=b&max=%sb&maxt=b\">%size</a></div></td>\r\n"
            "<td>%last_modified</td>\r\n"
            "</tr>\r\n";
    if(type_tmp=="path"){
        mask =
                "<td>%num</td>\r\n"
                "<td><div class=\"tc\"><a href=\"%urlpath\">ftp://%ip%path/</a></div></td>\r\n"
                "</tr>\r\n";
    }

    int total = tot;
    int pre = QString(getparam(content,(char*)"p=")).toInt();
    if(pre<0) pre=0;
    int cnt = QString(getparam(content,(char*)"c=")).toInt();
    int cnt_rec = 500;
    if(cnt==0)   cnt=cnt_rec;
    if(cnt<100)  cnt=100;
    if(cnt>5000) cnt=5000;
    if(tot-cnt-pre<0) tot=cnt+pre;
    if(total>0){

        if(type_tmp=="path"){
            printf("<div id=\"stat\">\r\n"
                    "    <table id=\"tablesorter\">\r\n"
                    "        <thead>\r\n"
                    "            <tr class=\"color\">\r\n"
                    "                <th>#</th>\r\n"
                    "                <th>Path</th>\r\n"
                    "            </tr>\r\n"
                    "        </thead>\r\n"
                    "        <tbody>\r\n");
        }
        else {
            printf("<div id=\"stat\">\r\n"
                    "    <table id=\"tablesorter\">\r\n"
                    "        <thead>\r\n"
                    "            <tr class=\"color\">\r\n"
                    "                <th>#</th>\r\n"
                    "                <th>Path</th>\r\n"
                    "                <th>File</th>\r\n"
                    "                <th>Size</th>\r\n"
                    "                <th>Last modified</th>\r\n"
                    "            </tr>\r\n"
                    "        </thead>\r\n"
                    "        <tbody>\r\n");
        }

        if(full.isEmpty()){
            query_text = QString("SELECT * FROM ftp_files LIMIT %1, %2;")
                    .arg(tot-cnt-pre).arg(cnt);
            if(type_tmp=="path"){
                query_text.replace("SELECT *","SELECT DISTINCT `path`,`ip`");
                query_text.replace("LIMIT","ORDER BY `path` LIMIT ");
            }
        }
        else{	query_text = QString("SELECT * FROM ftp_files WHERE %1 ORDER BY "
            "`%2` desc LIMIT %3, %4;").arg(full.mid(3,-1))
                    .arg("last_modified").arg(tot-cnt-pre).arg(cnt);
            if(type_tmp=="path"){
                query_text.replace("SELECT *","SELECT DISTINCT `path`,`ip`");
                query_text.replace("`last_modified`","`path`");
                query_text.replace("desc","");
            }
        }
        if(!sort.isEmpty() && type_tmp!="path"){
            if(sort=="time"){
                ;
            }
            else if(sort=="-time"){
                query_text.replace("desc","asc");
            }
            else if(sort=="file"){
                query_text.replace("`last_modified`","`file`");
            }
            else if(sort=="-file"){
                query_text.replace("`last_modified`","`file`");
                query_text.replace("desc","asc");
            }
            else if(sort=="ip"){
                query_text.replace("`last_modified`","`ip`");
            }
            else if(sort=="-ip"){
                query_text.replace("`last_modified`","`ip`");
                query_text.replace("desc","asc");
            }
            else if(sort=="size"){
                query_text.replace("`last_modified`","`size`+0");
            }
            else if(sort=="-size"){
                query_text.replace("`last_modified`","`size`+0");
                query_text.replace("desc","asc");
            }
            else if(sort=="path"){
                query_text.replace("`last_modified`","`path`");
            }
            else if(sort=="-path"){
                query_text.replace("`last_modified`","`path`");
                query_text.replace("desc","asc");
            }
        }
        if(!query.exec(query_text)){
            QString error = "Unable to do database operation "
                    "by following reason:\r\n"+
                    query.lastError().text()+"\r\n";
            save_error_log(error);
            printf("<br><center>Please reload this page.</center><br>\r\n");
            fix_some_bug = true;
        }else{
            QSqlRecord rec = query.record();
            int p[] = {rec.indexOf("ip"),rec.indexOf("path"),
                rec.indexOf("file"),rec.indexOf("size"),
                            rec.indexOf("last_modified")};
                            int num = 0;
                            while(query.next()){
                                ++num;
                                out = mask;

                                if(p[0]!=-1 && p[1]!=-1){
// 							    QUrl url(QString("ftp://%1%2/").arg(query.value(p[0]).toString()).arg(query.value(p[1]).toString()));
// 							    out.replace("%urlpath",url.toEncoded());
                                    out.replace("%urlpath","ftp://%ip%path/");
                                }
                                if(p[0]!=-1)	out.replace("%ip",query.value(p[0]).toString().toUtf8());
                                if(p[1]!=-1)	out.replace("%path",query.value(p[1]).toString().toUtf8());
                                if(p[2]!=-1)	out.replace("%file",query.value(p[2]).toString().toUtf8());
                                if(p[3]!=-1)	{QString unit="B"; QString qs="0";
                                    double ts = query.value(p[3]).toDouble();
                                    if((ts/1024) > 1) {ts=ts/1024; unit="KB";}
                                    if((ts/1024) > 1) {ts=ts/1024; unit="MB";}
                                    if((ts/1024) > 1) {ts=ts/1024; unit="GB";}
                                    if((ts/1024) > 1) {ts=ts/1024; unit="TB";}
                                    qs = QString::number(ts,'f',2);
                                    out.replace("%size",QString("%1 %2").arg(qs).arg(unit).toUtf8());
                                    out.replace("%sb",query.value(p[3]).toString().toUtf8());}
                                    if(p[4]!=-1)	out.replace("%last_modified",query.value(p[4]).toString().toUtf8());

                                    out.replace("%num",QString("%1").arg(num).toUtf8());
                                    if((num/2)*2==num) printf("<tr class=\"color\">\r\n");
                                    else printf("<tr>\r\n");
                                    printf("%s\r\n",out.data());
                            }
        }
        printf("</tbody></table><br></div>\r\n");
    }
    else	printf("<br><center>Nothing found!</center><br>");

    if(total>0){
        print_scroll(content,cnt,cnt_rec,pre,tot,total);
    }

    footer();
}

void ftp_stat(char *content)
{
    QFile file(path+"header.html");
    QByteArray out;
    if(file.open(QIODevice::ReadOnly | QIODevice::Text)){
        out = file.readAll();
        file.close();
        out.replace("%title","Ftp statistics");
        if(QString(getparam(content,(char*)"p=")).isEmpty())
            out.replace("<a href=\"./stat\">Ftp statistics</a>",
                        "<font  style=\"color : #444444;\">Ftp statistics</font>");
        printf("%s\r\n",out.data());
    }

    printf("    <div id=\"statText\">\r\n");

    QByteArray mask =
            "<td>%num</td>\r\n"
            "<td><div class=\"tc\"><a href=\"ftp://%ip/\">%ip</a></div></td>\r\n"
            "<td>%last_update</td>\r\n"
            "<td><div class=\"tc\">%files_number</div></td>\r\n"
            "<td><div class=\"tc\">%total_size</div></td>\r\n"
            "</tr>\r\n";

    int tot=0;
    QSqlQuery query;
    if(!query.exec("SELECT COUNT(*) FROM ftp_info;")){
        QString error = "Unable to do database operation "
                "by following reason:\r\n"+
                query.lastError().text()+"\r\n";
        save_error_log(error);
        printf("<br><center>Please reload this page.</center><br>\r\n");
        fix_some_bug = true;
    }else{
        query.last();
        tot = query.value(0).toInt();
    }

    int total = tot;
    int pre = QString(getparam(content,(char*)"p=")).toInt();
    if(pre<0) pre=0;
    int cnt = QString(getparam(content,(char*)"c=")).toInt();
    int cnt_rec = 500;
    if(cnt==0)   cnt=cnt_rec;
    if(cnt<100)  cnt=100;
    if(cnt>5000) cnt=5000;
    if(tot-cnt-pre<0) tot=cnt+pre;
    if(total>0){
        QByteArray mask2 = 
                "<br><b>Total number of FTP servers: </b>%totServ\r\n"
                "<br><b>Total number of files: </b>%totFiles\r\n"
                "<br><b>Total file size: </b>%totSize\r\n";
        file.setFileName(path+"stat.html");
        if(file.open(QIODevice::ReadOnly | QIODevice::Text)){
            QByteArray out = file.readAll();
            file.close();
            if(!out.isEmpty()) mask2 = out;
        }
		
        QString query_text;
        QByteArray totFiles;
        QByteArray totSize;
        int totServ = 0;
		
        query_text = QString("SELECT COUNT(`ip`) FROM `ftp_info` "
                "WHERE `files_number`>0;");
        if(query.exec(query_text)){
            if(query.last()) totServ = query.value(0).toInt();
        }
        query_text = QString("SELECT SUM(`files_number`) FROM `ftp_info` "
                "WHERE `files_number`>0;");
        if(query.exec(query_text)){
            if(query.last()) totFiles = query.value(0).toString().toUtf8();
        }
        query_text = QString("SELECT SUM(`total_size`) FROM `ftp_info` "
                "WHERE `files_number`>0;");
        if(query.exec(query_text)){
            if(query.last()){
                QString unit="B"; QString qs="0";
                double ts = query.value(0).toDouble();
                if((ts/1024) > 1) {ts=ts/1024; unit="KB";}
                if((ts/1024) > 1) {ts=ts/1024; unit="MB";}
                if((ts/1024) > 1) {ts=ts/1024; unit="GB";}
                if((ts/1024) > 1) {ts=ts/1024; unit="TB";}
                qs = QString::number(ts,'f',2);
                totSize = QString("%1 %2").arg(qs).arg(unit).toUtf8();
            }
        }
		
        mask2.replace("%totServ",QString("%1").arg(totServ).toUtf8());
        mask2.replace("%totFiles",totFiles);
        mask2.replace("%totSize",totSize);
        printf("%s\r\n",mask2.data());

        printf("<br>\r\n");
        printf("<div id=\"stat\">\r\n"
                "    <table id=\"tablesorter\">\r\n"
                "        <thead>\r\n"
                "            <tr class=\"color\">\r\n"
                "                <th>#</th>\r\n"
                "                <th>IP</th>\r\n"
                "                <th>Last update</th>\r\n"
                "                <th>Number of files</th>\r\n"
                "                <th>Total size</th>\r\n"
                "            </tr>\r\n"
                "        </thead>\r\n"
                "        <tbody>\r\n");

        QString sort = QString(getparam(content,(char*)"s="));
        query_text = QString("SELECT * FROM ftp_info ORDER BY "
                "`%1` desc LIMIT %2, %3;").arg("last_update").arg(tot-cnt-pre).arg(cnt);
        if(!sort.isEmpty()){
            if(sort=="time"){
                ;
            }
            else if(sort=="-time"){
                query_text.replace("desc","asc");
            }
            else if(sort=="num"){
                query_text.replace("`last_update`","`files_number`+0");
            }
            else if(sort=="-num"){
                query_text.replace("`last_update`","`files_number`+0");
                query_text.replace("desc","asc");
            }
            else if(sort=="ip"){
                query_text.replace("`last_update`","`ip`");
            }
            else if(sort=="-ip"){
                query_text.replace("`last_update`","`ip`");
                query_text.replace("desc","asc");
            }
            else if(sort=="size"){
                query_text.replace("`last_update`","`total_size`+0");
            }
            else if(sort=="-size"){
                query_text.replace("`last_update`","`total_size`+0");
                query_text.replace("desc","asc");
            }
        }
        if(!query.exec(query_text)){
            QString error = "Unable to do database operation "
                    "by following reason:\r\n"+
                    query.lastError().text()+"\r\n";
            save_error_log(error);
            printf("<br><center>Please reload this page.</center><br>\r\n");
            fix_some_bug = true;
        }else{
            QSqlRecord rec = query.record();
            int p[] = {rec.indexOf("ip"),rec.indexOf("files_number"),
                rec.indexOf("total_size"),rec.indexOf("last_update")
            };
            int num = 0;
            while(query.next()){
                ++num;
                out = mask;

                if(p[0]!=-1)
                    out.replace("%ip",query.value(p[0]).toString().toUtf8());
                if(p[1]!=-1)
                    out.replace("%files_number",query.value(p[1]).toString().toUtf8());
                if(p[2]!=-1) {
                    QString unit="B"; QString qs="0";
                    double ts = query.value(p[2]).toDouble();
                    if((ts/1024) > 1) {ts=ts/1024; unit="KB";}
                    if((ts/1024) > 1) {ts=ts/1024; unit="MB";}
                    if((ts/1024) > 1) {ts=ts/1024; unit="GB";}
                    if((ts/1024) > 1) {ts=ts/1024; unit="TB";}
                    qs = QString::number(ts,'f',2);
                    out.replace("%total_size",QString("%1 %2").arg(qs).arg(unit).toUtf8());
                }
                if(p[3]!=-1)
                    out.replace("%last_update",query.value(p[3]).toString().toUtf8());

                out.replace("%num",QString("%1").arg(num).toUtf8());
                if((num/2)*2==num) printf("<tr class=\"color\">\r\n");
                else printf("<tr>\r\n");
                printf("%s\r\n",out.data());
            }
        }
    }
    printf("</tbody></table><br></div>\r\n");

    printf("    </div>\r\n");

    if(total>0){
        print_scroll(content,cnt,cnt_rec,pre,tot,total);
    }
	
    footer();
}

void ftp_find()
{
    QFile file(path+"header.html");
    QByteArray out;
    if(file.open(QIODevice::ReadOnly | QIODevice::Text)){
        out = file.readAll();
        file.close();
        out.replace("%title","Ftp searcher");
        out.replace("<a href=\"./\">Ftp searcher</a>",
                    "<font  style=\"color : #444444;\">Ftp searcher</font>");
        printf("%s\r\n",out.data());
    }
	
    file.setFileName(path+"find.html");
    if(file.open(QIODevice::ReadOnly | QIODevice::Text)){
        QByteArray out = file.readAll();
        file.close();
        printf("%s\r\n",out.data());
    }
	
    footer();
}

QString shadeText(QString text)
{
    text.replace("\\","\\\\");
    text.replace("\'","\'\'");
    text.replace("\"","\\\"");
    return text;
}

char *getparam(char *buffer,char *name)
{
    if (buffer==NULL) return NULL;

    char *pos;
    long leng=512,i=0,j=0;
    char h1,h2;

    char *p=(char *)malloc(leng);
    pos=strstr(buffer,name);
    if (pos == NULL) return NULL;

    if ((pos!=buffer) && (*(pos-1)!='&')) return NULL; 

    pos+=strlen(name);
 
    while ( (*(pos+i)!='&')&&( *(pos+i)!='\0' ))
    {
        if ( *(pos+i)=='%' )
        {
            i++;
            h1=gethex(*(pos+i));
            i++;
            h2=gethex(*(pos+i));
            h1=h1<<4;
            *(p+j)=h1+h2;
        }
        else
        {
            if (*(pos+i)!='+') *(p+j)=*(pos+i);
            else *(p+j)=' ';
        };
        i++;
        j++;
        if (j >= leng) p=(char*)realloc(p,leng+20);
        leng+=20;
    };
    if (j < leng) p=(char*)realloc(p,j+1);
      
    *(p+j)='\0';
    return p;
}

char upperchar(char ch)
{
    if ((ch>='a') && (ch<='z'))
    {
        ch='A'+(ch - 'a');
        return ch;
    }
    else return ch;
}

char gethex(char ch)
{
    ch=upperchar(ch);
    if ((ch>='0')&&(ch<= '9')) return (ch-'0');
    if ((ch>='A')&&( ch<='F')) return (ch-'A'+10);
    return ch;
}

void print_scroll(char *content, int cnt, int cnt_rec, int pre, int tot, int total)
{
    QString full = getenv("REQUEST_URI");
    if(!full.isEmpty()){
        QString temp_param;
        temp_param = QString(getparam(content,(char*)"p="));
        if(!temp_param.isEmpty()){
            full.replace("&p="+temp_param,"");
            full.replace("p="+temp_param,"");
        }
        temp_param = QString(getparam(content,(char*)"c="));
        if(!temp_param.isEmpty()){
            full.replace("&c="+temp_param,"");
            full.replace("c="+temp_param,"");
        }
    }
    if(cnt!=cnt_rec) full.append(QString("&c=%1").arg(cnt));

    QString prev;
    if(pre-cnt>=0)
        prev=" <a href=\""
                +full+QString("&p=%1").arg(pre-cnt)+
                "\">&lt;&lt;&lt;&lt;</a>\r\n";
    else if(pre-cnt<0 && pre>0)
        prev=" <a href=\""
                +full+QString("&p=0")+
                "\">&lt;&lt;&lt;&lt;</a>\r\n";
    else	prev="\r\n &lt;&lt;&lt;&lt; ";

    QString next=" &gt;&gt;&gt;&gt; ";
    if(tot-cnt-pre>0){
        next = " <a href=\""
                +full+QString("&p=%1").arg(pre+cnt)+
                "\">&gt;&gt;&gt;&gt;</a> ";
    }
    QByteArray tmp = ("      <center>"+prev.toUtf8()
            +QString("%1").arg(pre).toUtf8()
            +QString(" / %1").arg(total).toUtf8()
            +next.toUtf8()+
            "\r\n      </center>\r\n"
            "      <br>\r\n");
    tmp.replace("?&","?");
    printf("%s\r\n",tmp.data());
}

