#ifndef __FUNC_H__
#define __FUNC_H__

#include <QTextStream>
#include <QByteArray>
#include <QString>
#include <QList>
#include <QProcess>
#include <QTextCodec>
#include <QStringList>
#include <QFile>
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QDateTime>
#include <QVariant>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlRecord>
#include <QSqlError>
#include <QVariant>
#include <QUrl>

#include <stdlib.h>
#include <string.h>
#include "fcgi_stdio.h"

void info();
void index();
void header();
void footer();
void save_log();
void save_error_log(QString error);
char *getparam(char *buffer,char *name);
char upperchar(char ch);
char gethex(char ch);
void ftp(char *content);
void ftp_stat(char *content);
void ftp_find();
void test_path(QString file);
QString  shadeText(QString text);
void print_scroll(char *content, int cnt, int cnt_rec, int pre, int tot, int total);

extern bool fix_some_bug;
extern QString path;
extern QString def_path;
extern QString log_path;


#endif // __FUNC_H__
