#ifndef SORTER_H
#define SORTER_H

#include <QObject>
#include <QCoreApplication>
#include <QProcess>
#include <QDir>
#include <QFile>
#include <QHostInfo>
#include <QVariant>
#include <QList>
#include <QByteArray>
#include <QProcess>
#include <QFtp>
#include <QTimer>
#include <QTextCodec>

#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QSqlRecord>
#include <QtPlugin>

class Sorter : public QObject
{
    Q_OBJECT

    public:
        Sorter(QObject *parent = 0);
        bool conf(QStringList args);
        void start();

    signals:
        void exitProg();

    private slots:
        void processFinished(int exitCode, QProcess::ExitStatus exitStatus);
        void ftpCommandFinished(int commandId, bool error);
        void addToList(const QUrlInfo &urlInfo);
        void commandStarted(int id);
        void quitProg();

    private:
        void init();
        void nextIp();
        void analyseIp();
        void checkData();
        void updateInfo();
        void get_iplist_from_db();

        void optimizeTable(QString table);
        QString shadeText(QString text);

        QList<QByteArray> iplist;
        QStringList progArgs;
        QString filename;
        QString progName;
        QString log;
        QString ip;
        QString ftp_user;
        QString ftp_pass;
        quint16 ftp_port;
        QFtp *ftp;
        QTimer *timer;
        QString coding;

        QStringList dir;
        QString curPath;

        quint64 files_number;
        quint64 total_size;
        quint64 min_size;

        QTextCodec *codec;
        QSqlDatabase db;
        QString table1;
        QString table2;
        QString table3;

        int updateTime;
        int runProcNum;
        int maxProcNum;
        int cutIpNum;
        bool check;
        bool child;
        bool scan;
        bool cutip;
        bool login;
        bool optimize;
};

#endif
