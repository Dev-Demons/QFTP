#include "qt-ftpsearcher.h"

void Sorter::checkData()
{
    if(coding.isEmpty() || ip.isEmpty()){
        emit exitProg();
        return;
    }

    if(!db.isOpen()) if(!db.open()){
        printf("Could'n open database %s:\r\n%s\r\n",
               db.databaseName().toUtf8().data(),
                               db.lastError().text().toUtf8().data());
        emit exitProg();
        return;
    }

    int tot=0;
    QSqlQuery query;
    QString query_text = QString("SELECT COUNT(*) FROM `%1` "
            "WHERE `ip`='%2';").arg(table1).arg(ip);
    if(!query.exec(query_text)){
        printf("Unable to do database operation:"
                "by following reason:\r\n%s\r\n",
                query.lastError().text().toUtf8().data());
    }else{
        query.last();
        tot = query.value(0).toInt();
    }

    QStringList update;
    if(tot>0){
        if(!query.exec(QString("SELECT * FROM `%1` "
            "WHERE `ip`='%2';").arg(table1).arg(ip))){
            printf("Unable to do database operation:"
                    "by following reason:\r\n%s\r\n",
                    query.lastError().text().toUtf8().data());
            }else{
                QTextCodec *codec0 = QTextCodec::codecForName(coding.toUtf8());
                QSqlRecord rec = query.record();
                int p[] = {rec.indexOf("path"),rec.indexOf("file")};
                QByteArray path_in;
                QByteArray file_in;
                QString path_out;
                QString file_out;
                while(query.next()){
                    if(p[0]!=-1) path_in = query.value(p[0]).toByteArray();
                    if(p[1]!=-1) file_in = query.value(p[1]).toByteArray();
                    path_out = codec0->toUnicode(path_in);
                    file_out = codec0->toUnicode(file_in);
                    if(QString(file_in)!=file_out || QString(path_in)!=path_out){
                        update << QString("UPDATE `%1` SET `%2`='%3', `%4`='%5' "
                                "WHERE `%6`='%7' AND `%8`='%9' "
                                "AND `%10`='%11';\n").arg(table1)
                                .arg("path").arg(shadeText(path_out))
                                .arg("file").arg(shadeText(file_out))
                                .arg("path").arg(shadeText(path_in))
                                .arg("file").arg(shadeText(file_in))
                                .arg("ip").arg(ip);
                    }
                }
            }
    }

    for(int i=0; i<update.size(); ++i){
        if(!query.exec(update[i])){
            printf("Unable to do database operation:"
                    "by following reason:\r\n%s\r\n",
                    query.lastError().text().toUtf8().data());
        }
    }

    db.close();
    emit exitProg();
// qApp->quit();
}

