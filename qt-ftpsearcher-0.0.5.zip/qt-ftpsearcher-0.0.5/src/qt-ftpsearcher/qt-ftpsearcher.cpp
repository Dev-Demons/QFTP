#include "qt-ftpsearcher.h"

Sorter::Sorter(QObject *parent):QObject(parent)
{
    init();
    connect(this, SIGNAL(exitProg()), qApp, SLOT(quit()));
}

void Sorter::start()
{
    if(child){
        if(check) checkData();
        else      analyseIp();
    }
    else if(optimize){
        if(!db.isOpen()) if(!db.open()){
            printf("Could'n open database %s:\r\n%s\r\n",
                   db.databaseName().toUtf8().data(),
                                   db.lastError().text().toUtf8().data());
            return;
        }
        optimizeTable(table1);
        optimizeTable(table2);
        optimizeTable(table3);
        db.close();
        return;
    }
    else{
        while(runProcNum<=maxProcNum)
            nextIp();
    }
}

void Sorter::init()
{
    scan=false;
    child=false;
    check=false;
    cutip=false;
    login=false;
    optimize=false;
    ftp_port=21;
    ftp_user="";
    ftp_pass="";
    cutIpNum=0;
    runProcNum=1;
    maxProcNum=5;
    min_size=0;
    total_size=0;
    files_number=0;
    updateTime=0;
    table1 = "ftp_files";
    table2 = "ftp_info";
    table3 = "ftp_encoding";
}

bool Sorter::conf(QStringList args)
{
    progName = args[0];
    db = QSqlDatabase::addDatabase("QMYSQL");

    QString arg;
    QString begin;
    QString ftp_code;
    int s=args.size();
    arg = args[s-1].toLower();
    if(arg=="-scan"){
        scan = true;
    }else if(arg=="-cutip"){
        cutip=true;
    }else if(arg=="-optimize"){
        optimize = true;
    }
    for(int i=0;i<s-1;++i){
        arg = args[i].toLower();
        if(arg=="-iplist"){
            filename = args[i+1];
        }
        if(arg=="-ip"){
            ip = args[i+1];
            child=true;
        }
        if(arg=="-cutip"){
            cutip=true;
        }
        if(arg=="-path"){
            QString tmp = args[i+1];
            if(!tmp.startsWith("/")) tmp.prepend("/");
            if(tmp.endsWith("/"))
                tmp.remove(tmp.size()-1,1);
            if(curPath.isEmpty())
                curPath = tmp;
            else	dir << tmp;
        }
        if(arg=="-ftp_user"){
            ftp_user = args[i+1];
        }
        if(arg=="-ftp_pass"){
            ftp_pass = args[i+1];
        }
        if(arg=="-ftp_port"){
            ftp_port = args[i+1].toInt();
            if(ftp_port==0) ftp_port=21;
        }
        if(arg=="-ftp_code"){
            ftp_code = args[i+1];
        }
        if(arg=="-log"){
            log = args[i+1];
        }
        if(arg=="-min"){
            QString tmpStr = args[i+1];
            if(tmpStr.endsWith("g")){
                tmpStr.remove("g");
                min_size = tmpStr.toInt()*1024*1024*1024;
            }
            else if(tmpStr.endsWith("m")){
                tmpStr.remove("m");
                min_size = tmpStr.toInt()*1024*1024;
            }
            else if(tmpStr.endsWith("k")){
                tmpStr.remove("k");
                min_size = tmpStr.toInt()*1024;
            }
            else	min_size = tmpStr.toInt();
        }
        if(arg=="-num"){
            maxProcNum = args[i+1].toInt();
            if(maxProcNum<=0) maxProcNum=5;
        }
        if(arg=="-time"){
            updateTime = args[i+1].toInt();
            if(updateTime<0) updateTime=0;
        }
        if(arg=="-begin"){
            begin = args[i+1];
        }
        if(arg=="-scan"){
            scan = true;
        }
        if(arg=="-optimize"){
            optimize = true;
        }
        if(arg=="-check"){
            coding = args[i+1];
            check = true;
        }
        if(arg=="-database"){
            db.setDatabaseName(args[i+1]);
        }
        if(arg=="-user"){
            db.setUserName(args[i+1]);
        }
        if(arg=="-password"){
            db.setPassword(args[i+1]);
        }
        if(arg=="-host"){
            db.setHostName(args[i+1]);
        }
        if(arg=="-port"){
            db.setPort(args[i+1].toInt());
        }
        if(arg=="-table1"){
            table1=args[i+1];
        }
        if(arg=="-table2"){
            table2=args[i+1];
        }
        if(arg=="-table3"){
            table3=args[i+1];
        }
    }
    args.removeAt(0);
    progArgs = args;

    if(ip.isEmpty() && child) return false;
    if(!filename.isEmpty() && !child){
        QFile file(filename);
        if(file.open(QIODevice::ReadOnly | QIODevice::Text)){
            QByteArray out = file.readAll();
            file.close();
            out.replace("\r","");
            iplist = out.split('\n');
            for(int i=iplist.size()-1; i>=0; --i){
                if(iplist[i].isEmpty())
                    iplist.removeAt(i);
                if(!begin.isEmpty())
                    if(iplist[i]==begin)
                        cutIpNum=i;
            }
        }else{
            printf("Couldn't open file: %s\n",
                   filename.toUtf8().data());
            return false;
        }
    }

    if(db.databaseName().isEmpty()){
        printf("Error:\nParameter -database is not specified.\n");
        return false;
    }else if(!db.databaseName().isEmpty() && child){
        if(!db.open()){
            printf("Could'n open database %s:\r\n%s\r\n",
                   db.databaseName().toUtf8().data(),
                                   db.lastError().text().toUtf8().data());
            return false;
        }
    }else if(filename.isEmpty() && !child && !db.databaseName().isEmpty()){
        if(!db.open()){
            printf("Could'n open database %s:\r\n%s\r\n",
                   db.databaseName().toUtf8().data(),
                                   db.lastError().text().toUtf8().data());
            return false;
        }else{
            get_iplist_from_db();
            if(iplist.isEmpty()) return false;
            db.close();
        }
    }

    QByteArray code("Windows-1251");
    if(!db.databaseName().isEmpty() && child && ftp_code.isEmpty()){
        QSqlQuery query;
        if(query.exec(QString("SELECT `%1` FROM `%2` WHERE `%3`='%4';")
           .arg("encoding").arg(table3).arg("ip").arg(ip)))
        {
            if(query.last()) code = query.value(0).toByteArray();
        }
    }else if(!db.databaseName().isEmpty() && child && !ftp_code.isEmpty()){
        QSqlQuery query;
        if(query.exec(QString("DELETE FROM `%1` WHERE `%2`='%3';")
           .arg(table3).arg("ip").arg(ip)))
        {
            query.exec(QString("INSERT INTO `%1` (`%2`,`%3`) VALUES ('%4','%5');")
                    .arg(table3).arg("encoding").arg("ip")
                    .arg(ftp_code).arg(ip));
        }
        code = ftp_code.toUtf8();
    }
    codec = QTextCodec::codecForName(code);

    return true;
}

void Sorter::get_iplist_from_db()
{
    int tot=0;
    QSqlQuery query;
    QString   queryStr = QString("SELECT COUNT(*) FROM %1;").arg(table2);
    if(updateTime>0){
        QDateTime time = QDateTime::currentDateTime().addSecs(-updateTime);
        queryStr.replace(";",QString(" WHERE `last_update`<='%1';")
                .arg(time.toString("yyyy-MM-dd hh:mm:ss")));
    }
    if(!query.exec(queryStr)){
        if(!query.exec(QString("CREATE TABLE `%1` (`%2` text, "
            "`%3` text, `%4` text, `%5` text) CHARSET=utf8;")
            .arg(table2).arg("ip").arg("last_update")
            .arg("files_number").arg("total_size")))
        {
            printf("Unable to do database operation:"
                    "by following reason:\r\n%s\r\n",
                    query.lastError().text().toUtf8().data());
        }
    }else{
        query.last();
        tot = query.value(0).toInt();
    }

    if(tot>0){
        queryStr = QString("SELECT * FROM %1 ORDER BY "
                "`%2`;").arg(table2).arg("last_update");
        if(updateTime>0){
            QDateTime time = QDateTime::currentDateTime().addSecs(-updateTime);
            queryStr.replace("ORDER",QString(" WHERE `last_update`<='%1' ORDER")
                    .arg(time.toString("yyyy-MM-dd hh:mm:ss")));
        }
        if(!query.exec(queryStr)){
            printf("Unable to do database operation:"
                    "by following reason:\r\n%s\r\n",
                    query.lastError().text().toUtf8().data());
        }else{
            QSqlRecord rec = query.record();
            int p = rec.indexOf("ip");
            while(query.next()){
                if(p!=-1) iplist << query.value(p).toString().toUtf8();
            }
        }
    }
}

QString Sorter::shadeText(QString text)
{
    text.replace("\\","\\\\");
    text.replace("\'","\'\'");
    text.replace("\"","\\\"");
    return text;
}

void Sorter::processFinished(int exitCode, QProcess::ExitStatus exitStatus)
{
    --runProcNum;
    if(cutIpNum>=iplist.size()+maxProcNum-1){
        QByteArray time = QDateTime::currentDateTime()
                .toString("hh:mm:ss").toAscii();
        printf("Scan finished successfully at %s.\r\n",time.data());
        db.close();
        emit exitProg();
    }
    else	nextIp();
}

void Sorter::nextIp()
{
    if(runProcNum>maxProcNum) return;
    if(cutIpNum<iplist.size()){
        QProcess *process = new QProcess(this);
        connect(process, SIGNAL(finished(int,QProcess::ExitStatus)),
                this, SLOT(processFinished(int, QProcess::ExitStatus)));
        connect(process, SIGNAL(finished(int,QProcess::ExitStatus)),
                process, SLOT(deleteLater()));
        process->start(progName,QStringList(progArgs) << "-ip" << iplist[cutIpNum]);
        if(!log.isEmpty()){
            QByteArray out = iplist[cutIpNum] + "\r\n";
            out += QString("%1\%").arg(100*cutIpNum/iplist.size());
            QFile file(log);
            if(file.open(QIODevice::WriteOnly | QIODevice::Text)){
                file.write(out);
                file.close();
            }
        }
    }
    ++runProcNum;
    ++cutIpNum;
}

void Sorter::analyseIp()
{
    if(!db.isOpen()) if(!db.open()){
        printf("Could'n open database %s:\r\n%s\r\n",
               db.databaseName().toUtf8().data(),
                               db.lastError().text().toUtf8().data());
        emit exitProg();
        return;
    }

    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(quitProg()));

    ftp   = new QFtp(this);
    connect(ftp, SIGNAL(commandStarted(int)),this,
            SLOT(commandStarted(int)));
    connect(ftp, SIGNAL(commandFinished(int, bool)),this,
            SLOT(ftpCommandFinished(int, bool)));
    connect(ftp, SIGNAL(listInfo(const QUrlInfo &)),this,
            SLOT(addToList(const QUrlInfo &)));
    ftp->connectToHost(ip,ftp_port);
    if(!ftp_user.isEmpty())
        ftp->login(ftp_user,ftp_pass);
    else	ftp->login();
    if(!scan){
        if(!curPath.isEmpty()){
            ftp->cd(curPath);
        }
        else	ftp->list();
    }
    else      ftp->close();
}

void Sorter::quitProg()
{
    if(login) updateInfo();
    ftp->abort();
    ftp->deleteLater();
    ftp = 0;
    db.close();
    emit exitProg();
}

void Sorter::ftpCommandFinished(int, bool error)
{
    if(ftp->currentCommand() == QFtp::ConnectToHost){
        timer->stop();
        if(error){
            quitProg();
            return;
        }
    }
    else if(ftp->currentCommand() == QFtp::Login){ // begin QFtp::Login
        timer->stop();
        if(error){
            quitProg();
            return;
        }
        login = true;
        int tot=0;
        QSqlQuery query;

        if(!query.exec(QString("SELECT COUNT(*) FROM `%1`;").arg(table2))){
            if(!query.exec(QString("CREATE TABLE `%1` (`%2` text, "
                "`%3` text, `%4` text, `%5` text) CHARSET=utf8;")
                .arg(table2).arg("ip").arg("last_update")
                .arg("files_number").arg("total_size")))
            {
                printf("Unable to do database operation:"
                        "by following reason:\r\n%s\r\n",
                        query.lastError().text().toUtf8().data());
            }
        }else{
            query.last();
            tot = query.value(0).toInt();
        }

        if(tot>0){
            if(!query.exec(QString("DELETE FROM `%1` WHERE ip='%2';")
                .arg(table2).arg(ip)))
            {
                printf("Unable to do database operation:"
                        "by following reason:\r\n%s\r\n",
                        query.lastError().text().toUtf8().data());
            }
        }

        QString time = QDateTime::currentDateTime()
                .toString("yyyy-MM-dd hh:mm:ss");
        if(!query.exec(QString("INSERT INTO `%1` (`%2`,`%3`,`%4`,`%5`)"
            " VALUES ('%6','%7','%8','%9');")
            .arg(table2).arg("ip").arg("last_update")
            .arg("files_number").arg("total_size")
            .arg(ip).arg(time).arg("-").arg("-")))
        {
            printf("Unable to do database operation:"
                    "by following reason:\r\n%s\r\n",
                    query.lastError().text().toUtf8().data());
        }

        tot=0;
        if(!query.exec(QString("SELECT COUNT(*) FROM `%1`;").arg(table1))){
            if(!query.exec(QString("CREATE TABLE `%1` (`%2` text, `%3` text, "
                "`%4` text, `%5` text, `%6` text) CHARSET=utf8;")
                .arg(table1).arg("ip").arg("path").arg("file")
                .arg("size").arg("last_modified")))
            {
                printf("Unable to do database operation:"
                        "by following reason:\r\n%s\r\n",
                        query.lastError().text().toUtf8().data());
            }
        }else{
            query.last();
            tot = query.value(0).toInt();
        }

        if(tot>0){
            if(!query.exec(QString("DELETE FROM `%1` WHERE ip='%2';")
                .arg(table1).arg(ip)))
            {
                printf("Unable to do database operation:"
                        "by following reason:\r\n%s\r\n",
                        query.lastError().text().toUtf8().data());
            }
// ----------------------------------
//       OPTIMIZE TABLE `table`;
//       ANALYZE TABLE `table`;
// ----------------------------------
        }
    } // end QFtp::Login

    else if(ftp->currentCommand() == QFtp::Cd){
        timer->stop();
        if(error){
            if(dir.isEmpty()){
                ftp->close();
                return;
            }
            int ind = dir.size()-1;
            curPath = dir[ind];
            dir.removeAt(ind);
            ftp->cd(curPath);
        }
        else	ftp->list();
    }
    else if(ftp->currentCommand() == QFtp::List){
        timer->stop();
        if(dir.isEmpty()){
            ftp->close();
            return;
        }
        int ind = dir.size()-1;
        curPath = dir[ind];
        dir.removeAt(ind);
        ftp->cd(curPath);
        updateInfo();
    }
    else if(ftp->currentCommand() == QFtp::Close){
        timer->stop();
        if(cutip && !filename.isEmpty() && !ip.isEmpty()){
            QFile file(filename);
            if(file.open(QIODevice::ReadOnly | QIODevice::Text)){
                QByteArray out = file.readAll();
                file.close();
                out.replace("\r","");
                out.replace(ip.toUtf8()+"\n","");
                out.replace("\n","\r\n");
                if(file.open(QIODevice::WriteOnly | QIODevice::Text)){
                    file.write(out);
                    file.close();
                }
            }
        }
        quitProg();
        return;
    }
}

void Sorter::commandStarted(int id)
{
    if(ftp->currentCommand() == QFtp::ConnectToHost){
        timer->start(15000);
    }
    else if(ftp->currentCommand() == QFtp::Login){
        timer->start(15000);
    }
    else if(ftp->currentCommand() == QFtp::List){
        timer->start(60000);
    }
    else if(ftp->currentCommand() == QFtp::Cd){
        timer->start(60000);
    }
    else if(ftp->currentCommand() == QFtp::Close){
        timer->start(30000);
    }
}

void Sorter::addToList(const QUrlInfo &urlInfo)
{
    if(!urlInfo.isDir()){
        if((quint64)urlInfo.size() < min_size) return;
        files_number += 1;
        total_size += urlInfo.size();
        QSqlQuery query;
        if(!query.exec(QString("INSERT INTO `%1` (`%2`,`%3`,`%4`,`%5`,`%6`)"
            " VALUES ('%7','%8','%9','%10','%11');").arg(table1)
            .arg("ip").arg("path").arg("file")
            .arg("size").arg("last_modified")
            .arg(ip).arg(shadeText(codec->toUnicode(
                 QVariant(curPath).toByteArray())))
            .arg(shadeText(codec->toUnicode(
                 QVariant(urlInfo.name()).toByteArray())))
            .arg(urlInfo.size()).arg(urlInfo.lastModified()
            .toString("yyyy-MM-dd hh:mm:ss"))))
        {
            printf("Unable to do database operation:"
                    "by following reason:\r\n%s\r\n",
                    query.lastError().text().toUtf8().data());
        }
    }
    else{
        if(urlInfo.name()=="." || urlInfo.name()=="..") return;
        dir << curPath + "/" + urlInfo.name();
    }
}

void Sorter::updateInfo()
{
    QString time = QDateTime::currentDateTime()
            .toString("yyyy-MM-dd hh:mm:ss");
    QSqlQuery query;
    if(!query.exec(QString("UPDATE `%1` SET "
        "`%3`='%7',`%4`='%8',`%5`='%9' "
        "WHERE `%2`='%6';")
        .arg(table2).arg("ip").arg("last_update")
        .arg("files_number").arg("total_size")
        .arg(ip).arg(time).arg(files_number)
        .arg(QString::number(total_size))))
    {
        printf("Unable to do database operation:"
                "by following reason:\r\n%s\r\n",
                query.lastError().text().toUtf8().data());
    }
}

void Sorter::optimizeTable(QString table)
{
    QSqlQuery query;
    QString query_text = QString("OPTIMIZE TABLE `%1`;").arg(table);
    bool res = query.exec(query_text);
    if(!res){
        printf("Unable to do database operation:"
                "by following reason:\r\n%s\r\n",
                query.lastError().text().toUtf8().data());
    }
    query_text = QString("ANALYZE TABLE `%1`;").arg(table);
    res = query.exec(query_text);
    if(!res){
        printf("Unable to do database operation:"
                "by following reason:\r\n%s\r\n",
                query.lastError().text().toUtf8().data());
    }
}

