********** Linux installing **********
Install fastcgi files (headers and libraries) from your repository or make from sources.

Check paths in file src/qt-ftpsearcher-webui/qt-ftpsearcher-webui.pro in unix section.

./configure
make
sudo make install
or
su -c 'make install'


********** Windows installing **********
Download fastcgi. For example:

Source-files from official site:
http://www.fastcgi.com/drupal/node/5
or
Binary-files compiled in cygwin:
http://repo.fedoramd.org/mirrors/cygwin/release/fcgi/
or
Binary-files compiled in mingw:
http://devpaks.org/details.php?devpak=63

Edit src/qt-ftpsearcher-webui/qt-ftpsearcher-webui.pro in win32 section.

Check all required plugins in %QTDIR%\plugins\sqldrivers\

Edit (check using paths) and run script files:
configure.bat
make_.bat
make_install.bat
xcopy /Y /E Qt-FtpSearcher "c:\Program Files\Qt-FtpSearcher\"

