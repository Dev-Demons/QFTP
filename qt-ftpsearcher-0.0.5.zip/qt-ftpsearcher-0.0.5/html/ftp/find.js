function hideObjects() {
    if(document.getElementById("f1").style.visibility=="visible"){
        document.getElementById("f1").style.visibility="hidden";
        document.getElementById("f2").style.visibility="hidden";
        document.getElementById("f3").style.visibility="hidden";
    }
    else{
        document.getElementById("f1").style.visibility="visible";
        document.getElementById("f2").style.visibility="visible";
        document.getElementById("f3").style.visibility="visible";
    }
}

