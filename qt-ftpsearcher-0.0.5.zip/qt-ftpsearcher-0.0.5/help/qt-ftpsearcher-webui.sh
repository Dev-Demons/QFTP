#!/bin/sh

## ABSOLUTE path to the spawn-fcgi binary
SPAWNFCGI="/usr/bin/spawn-fcgi"

## ABSOLUTE path to the binary
FCGIPROGRAM="/usr/bin/qt-ftpsearcher-webui"

## TCP port to which to bind on localhost
FCGIPORT="1029"

## number of children to spawn
FCGI_CHILDREN=1

## if this script is run as root, switch to the following user
USERID=user
GROUPID=user


################## no config below this line

if test x$FCGI_CHILDREN = x; then
  FCGI_CHILDREN=5
fi

if test x$UID = x0; then
  EX="$SPAWNFCGI -p $FCGIPORT -f $FCGIPROGRAM -u $USERID -g $GROUPID -C $FCGI_CHILDREN"
else
  EX="$SPAWNFCGI -p $FCGIPORT -f $FCGIPROGRAM -C $FCGI_CHILDREN"
fi

# clean the environment and set up a new one
env - $E $EX
