% This is example of simple script which generate ip list
% Edit this script and run in Octave or MatLab.

%  # http://www.spb.edu/campus/networks.txt
%
%  # Networks list of Campus of SPbU
%  # (format: network/prefix\tdescription\n)
%
%  81.89.188.0/23	campus1
%  217.197.9.0/24	campus1
%  81.89.186.0/23	campus2
%  81.89.178.0/23	campus3
%  81.89.176.0/23	campus4
%  81.89.180.0/24	campus5
%  92.42.30.0/24	campus10
%  92.42.28.0/24	campus12
%  92.42.31.0/24	campus13
%  92.42.26.0/23	campus14
%  217.197.10.0/24	campus14
%  217.197.0.0/23	campus15
%  217.197.7.0/24	campus15
%  217.197.6.0/24	campus16
%  81.89.181.0/24	campus17
%  195.70.216.0/24	campus18
%  217.197.11.0/24	campus20
%  217.197.2.0/23	campus21
%  217.197.4.0/23	campus22
%  217.197.8.0/24	campus23
%  81.89.185.0/24	campus99

fid = fopen('iplist_best.txt','w');
for p3=0:11;
    for p4=0:254;
        fwrite(fid,sprintf('217.197.%i.%i\r\n',p3,p4));
    end;
end;
for p3=[176:181,185:189];
    for p4=0:254;
        fwrite(fid,sprintf('81.89.%i.%i\r\n',p3,p4));
    end;
end;
for p3=[26,27,28,30,31];
    for p4=0:254;
        fwrite(fid,sprintf('92.42.%i.%i\r\n',p3,p4));
    end;
end;
for p3=216;
    for p4=0:254;
        fwrite(fid,sprintf('195.70.%i.%i\r\n',p3,p4));
    end;
end;
fclose(fid);

