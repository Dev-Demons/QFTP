#!/bin/sh

rm -f iplist_best.txt

for p3 in $(seq 26 27) ; do
  for p4 in $(seq 0 255) ; do
    echo "92.42.$p3.$p4" >> iplist_best.txt
  done
done

# I am some lazy for copy full ip diapazon from http://www.spb.edu/campus/networks.txt
# I think you understand the main idea. =)

echo "Done."
