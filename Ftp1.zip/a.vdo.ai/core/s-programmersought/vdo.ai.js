/*12-Dec-2024 05:13:24*/
    
    if(Math.random()  <= 0.0001)
    {(function (c, l, a, r, i, t, y) {
        c[a] = c[a] || function () { (c[a].q = c[a].q || []).push(arguments);};
        t = l.createElement(r);
        t.async = 1;
        t.src = 'https://www.clarity.ms/tag/' + i;
        y = l.getElementsByTagName(r)[0];
        y.parentNode.insertBefore(t, y);
      })(window, document, 'clarity', 'script', 'jxi9v3zs1f');
    }

   var vdo_analyticsID = 'G-8J9SC9WB3T';
    (function(v, d, o, ai) {
        ai = d.createElement('script');
        ai.async = true;
        ai.src = o;
        d.head.appendChild(ai);
    })(
        window,
        document,
        'https://www.googletagmanager.com/gtag/js?id=' + vdo_analyticsID
    );

    function vdo_analytics() {
        window.dataLayer.push(arguments);

    }
    (function () {
      window.dataLayer = window.dataLayer || [];
      vdo_analytics("js", new Date());
    })();
    vdo_analytics('event', 'loaded', { send_to: vdo_analyticsID, event_category: 'vdoaijs', event_label: 's-programmersought' });

  window.vdo_ai_ = window.vdo_ai_ ? window.vdo_ai_ : {};
    window.vdo_ai_.dimensions = window.vdo_ai_.dimensions || [];
    window.vdo_ai_.customDimensions = window.vdo_ai_.customDimensions || {};
    if(window.vdo_ai_.dimensions.length) {
        var items = window.vdo_ai_.dimensions;
        window.vdo_ai_.dimensions = [];
        items.forEach(customDimensions);
    }
    window.vdo_ai_.dimensions.push = customDimensions;
    function customDimensions(arr) {
        try {
          var tagname = arr[0],
            dimentionName = arr[1],
            dimentionValue = arr[2];
      
          if (dimentionName && dimentionName != '') {
            var dimensionCount = parseInt(dimentionName.replace('dim', ''));
            if (dimensionCount && dimensionCount <= 0) {
              if (!window.vdo_ai_.customDimensions[tagname]) {
                window.vdo_ai_.customDimensions[tagname] = {};
              }
              window.vdo_ai_.customDimensions[tagname][dimentionName] =
                dimentionValue;
            }
          }
        } catch (error) {
          logError(error, 's-programmersought');
        }
      }

function logPixel(requestObject){

    if(window.vdo_ai_.customDimensions && window.vdo_ai_.customDimensions['s-programmersought']) {
        requestObject.dimensions = window.vdo_ai_.customDimensions['s-programmersought'];
    }

    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'https://analytics.vdo.ai/logger', true);

    xhr.send(JSON.stringify(requestObject));
    xhr.onerror = () => {
        var xhrFailedRequest = new XMLHttpRequest();
        xhrFailedRequest.open('POST', 'https://analytics1.vdo.ai/logger', true);
        xhrFailedRequest.send(JSON.stringify(requestObject));
    };
}

var requestObject = {
  domainName: location.hostname,
  page_url:location.href,
  tagName: 's-programmersought',
  event: 'loaded',
  eventData: 1,
  uid: ''
};

logPixel(requestObject);

function logError(e, tagname) {
if (typeof e === 'string') {
  e = {
    message: e,
    stack: e,
  };
} else {
  e = {
    message: btoa(e.message).substr(0, 10),
    stack: encodeURIComponent(e.stack),
  };
}vdo_analytics('event', 'Err:' + e.message, {
    send_to: vdo_analyticsID,
    event_label: tagname,
    event_category: 'VDOError',
  });
var oReq = new XMLHttpRequest();
oReq.open(
  'get',
  '//a.vdo.ai/core/logger.php?msg=' +
    e.stack +
    '&tag=' + tagname + '&code=' +
    e.message +
    '&url=' +
    encodeURIComponent(location.href) +
    '&func=vdo.ai.js',
  true
);
oReq.send();
var requestObject = {
  domainName: location.hostname,
  page_url: location.href,
  tagName: tagname,
  event: 'error',
  eventData: e.message,
  uid: '',
};
logPixel(requestObject);
}


try {



function insideSafeFrame() {
  try {
    if(top.location.href) {
      return false;
    }
  } catch (error) {
    return true;
  }
}


function findIframeContainingSelf() {
  let selfParent = self; 
  try {
      for (let i = 0; i <= 5; i++) {
        if(i == 5) {
          console.log('VDO Error : ',"nested iframes allowed upto 5."); 
        }else{ 
          if (selfParent.parent === top) return selfParent;
          else selfParent = selfParent.parent;
        }
      }
  } catch (e) {
      logError(e, "s-programmersought")
  }
}
  
var w_vdo = (insideSafeFrame()) ? window : window.top,
d_vdo = w_vdo.document;
(function (window, document, deps, publisher) {
  var protocol = window.location.protocol;

  window.vdo_ai_stories = window.vdo_ai_stories || {};
  window.vdo_ai_stories.cmd = window.vdo_ai_stories.cmd || [];

    function loadPlayerDiv(id,parentId,iframeBurst=false) {
    if (!iframeBurst) {
      if(document.getElementById(id) == null) {
        var s = document.createElement('div');
        s.id = id;
      } else{
        var s = document.getElementById(id);
      }
       if (parentId != '') {
         var parentDiv = document.getElementById(parentId);
         parentDiv.style.display = "block";
         parentDiv.style.width = "100%";
         parentDiv.appendChild(s);
       } else{
         document.body.appendChild(s);
       }

    } else{

        var targetIframe = findIframeContainingSelf();
        var el = targetIframe && targetIframe.frameElement;
        if (el) {
            // here you can create an expandable ad
            var s = document.createElement('div');
            s.style.zIndex=111;
            s.style.margin = "0 auto";
            s.style.display = "block";
            s.style.position = "relative";
            s.width = 'fit-content';
            s.id = id;
            var googleDiv = el.parentNode;


            if (parentId != '') {
                var parentDiv = document.createElement('div');
                parentDiv.id = parentId;
                parentDiv.style.display = "block";
                parentDiv.style.width = "100%";
                parentDiv.appendChild(s);
                googleDiv.insertBefore(parentDiv, el);
            } else{
                googleDiv.insertBefore(s, el);
            }


            googleDiv.style.width = "auto";
            googleDiv.parentNode.style.width='auto';
            googleDiv.parentNode.style.height='auto';
            
            el.style.height = "0px";
            el.style.width = "0px";        
      }
    }
  }

  

  var playerLoaded = false;
  var adframeConfig = {"desktop":{"show":true,"muted":true,"width":480,"height":270,"bottomMargin":10,"topMargin":10,"unitType":"content","leftOrRight":{"position":"right","margin":10},"cancelTimeoutType":{"type":"timeout","eventtype":"readyforpreroll","cancelTimeout":20000},"passback":{"allow":true,"src":"","string":"","timeout":15000,"type":"timeout","value":15000},"smallWidth":498,"smallHeight":280,"crossSize":20,"dispose_off":true,"bannerOff":false,"companionOff":true,"taboola_overlap_exception":false,"autoResize":false},"mobile":{"dispose_off":true,"show":true,"muted":true,"width":333,"height":250,"bottomMargin":10,"topMargin":10,"unitType":"content","leftOrRight":{"position":"right","margin":10},"cancelTimeoutType":{"type":"timeout","eventtype":"readyforpreroll","cancelTimeout":20000},"passback":{"allow":true,"type":"timeout","value":15000,"src":"","string":"","timeout":15000},"smallWidth":333,"smallHeight":250,"crossSize":20,"bannerOff":false,"companionOff":true,"taboola_overlap_exception":false,"autoResize":false},"bottomMargin":10,"cancelTimeout":10000,"id":"vdo_ai_8118","muted":true,"playsinline":true,"autoplay":true,"preload":true,"video_clickthrough_url":"","pubId":"1805","brandLogo":{"img":"","url":""},"coppa":false,"add_on_page_ready":"no","showLogo":true,"parent_div":"s-programmersought","adbreak_offsets":[0,5,10],"show_on_ad":false,"close_after_first_ad_timer":0,"canAutoplayCheck":true,"playlist_url":"","playlistType":"local","domain":"programmersought.com","path":"a.vdo.ai\/core\/s-programmersought\/adframe.js","unitId":"_vdo_ads_player_ai_3182","tag_type":"other","content_sources":[{"video":"uploads\/videos\/16606297237362fb32dbdc7bc","img":"uploads\/thumbnails\/16606297237362fb32dbdc7bc.png","duration":3003,"title":"Why%20will%205G%20change%20how%20we%20surf%20the%20internet%3F","keyword":""},{"video":"uploads\/videos\/16596063615762eb9559b523f","img":"uploads\/thumbnails\/16596063615762eb9559b523f.png","duration":3000,"title":"What%20are%20Metaverse%20games%20and%20how%20can%20it%20affect%20our%20economy","keyword":""},{"video":"uploads\/videos\/16599447384462f0bf220db4e","img":"uploads\/thumbnails\/16599447384462f0bf220db4e.png","duration":3025,"title":"What%20is%20edge%20computing%20and%20why%20is%20it%20important%3F","keyword":""},{"video":"uploads\/videos\/16693691941663808d6a52ef6","img":"uploads\/thumbnails\/16693691941663808d6a52ef6.png","duration":3003,"title":"Benefits%20of%20Learning%20different%20languages","keyword":""}],"playlist_id":null,"realParentDiv":"s-programmersought","static_vpmute":true,"allowed_dims":0,"dependency":"dependencies_stories_v1","pubId_vdo":"1805_2799","pubId_atlas":"1805_2799","pubId_wc":"1805","pubId_jj":"","pubId_adsolut":"","pubId_hs":"","media_url":"https:\/\/h5.vdo.ai\/media_file\/s-programmersought\/source\/","show_on":"ads-ad-started","ga_event":true,"use_global_hls":false,"tagType":"stories","google_mcm":"","google_mcm_apac":"22316101559","bidders":[],"targeting":[],"ibv_linked_tag":"","adx":[],"s2s":false,"overflow_size":false,"handle_url_change":true,"style":"","ver":"v5.3.7","vast":[],"companionBanner":{"google_mcm":{"placement":"","upr":""},"gtr":{"include":["RO","GB","CA","DE","US","AE","AU"]},"rgtr":[{"geos":["RO","GB","CA","DE","US","AE","AU"],"time":30}]},"nonLinearBanner":{"google_mcm":{"placement":"","upr":""},"gtr":{"include":["BE","BG","BR","RO","JP","GB","HU","PT","PL","ZA","ES","FR","FI","NL","NO","NZ","CH","CA","SK","KR","SE","DK","DE","US","AE","IS","AU","AT","IE"]}},"storiesData":{"items":[{"img":"https:\/\/images3.programmersought.com\/520\/57\/5767511819b392e6e4ba4d9779f8bb98.png","title":"Qt interprocess communication (1) --------QProcess","description":"","url":"https:\/\/programmersought.com\/article\/8623174116\/"},{"img":"https:\/\/images4.programmersought.com\/839\/f7\/f795068f4ac9b6046f8cd4803e8f8207.png","title":"Zabbix disk performance monitoring","description":"","url":"https:\/\/programmersought.com\/article\/1097252269\/"},{"img":"https:\/\/images2.programmersought.com\/393\/5f\/5f39eb82ed3c3ffd39cb8bb5827ae1c9.png","title":"Golang tcp forwarding remoteAddr error","description":"","url":"https:\/\/programmersought.com\/article\/58952726946\/"},{"img":"https:\/\/images1.programmersought.com\/11\/be\/be2f47f1429805666899daf3af11f7eb.png","title":"Zabbix disk performance for use (the iostat) monitoring the linux","description":"","url":"https:\/\/programmersought.com\/article\/91062533805\/"}]}};

  var checkTimer;


  function callAdframe() {
    if(!playerLoaded) {
        playerLoaded = true;
        clearInterval(checkTimer);
        window.vdo_ai_stories.cmd.push(function() {
          window.initVdoStories(adframeConfig);
        });

    }
  }


  function loadScriptSync(src, id) {
    return new Promise(function(resolve, reject) {

        if(src.indexOf('ima3.js') > 0 && document.querySelector('script[src*="imasdk.googleapis.com/js/sdkloader/ima3.js"]')) {
          if(window.google && window.google.ima) {

            resolve();
            return false;
          } else {
            document.querySelector('script[src*="imasdk.googleapis.com/js/sdkloader/ima3.js"]').addEventListener('load', resolve);
            return false;
          }
        }
        var s = document.createElement("script");
        s.id = id;
        var existingScript = document.getElementById(id);

        s.async = true;
        s.src = protocol + src;
        document.body.appendChild(s);
        var timestamp = Date.now();

        s.onload = function(e) {
          
          vdo_analytics('event', 'timing_complete', {
            name: 'load_' + (src.indexOf('vdo.min.js') >= 0 ? 'vdo.min.js' : 'ima3.js'),
            value: Date.now() - timestamp,
            event_category: 'stories',
            send_to: vdo_analyticsID,
            event_label: "s-programmersought",
          });

          resolve();
        };

      s.onerror = function (e) {
        if (src.includes("ima3.js")) {
          var blockedImaObject = {
            domainName: location.hostname,
            page_url: location.href,
            tagName: "s-programmersought",
            event: "blocked_ima",
            eventData: 1,
          };
          logPixel(blockedImaObject);
            vdo_analytics("event", "blocked_ima", {
    send_to: vdo_analyticsID,
    event_category: "vdoaijs",
    event_label: "s-programmersought",
    page_location: location.href,
    page_title: document.title,
  });
        }
        resolve();
      };
      
      })
  }

  function inIframe(){try{return self!==top}catch(r){return!0}}var iframe_Burst=inIframe() ? insideSafeFrame() ? false : true : false;



  //#region full_dependencies testing
  function startTag(version){

    loadPlayerDiv('_vdo_ads_player_ai_3182','s-programmersought',iframe_Burst);



checkTimer = setInterval(function() {
    if(window.initVdoStories && typeof window.google != 'undefined' && window.google.ima) {
        callAdframe();
    }
}, 1000);

if(typeof window.initVdoStories !== 'function') {  // Check for existing dependencies
    if (adframeConfig.dependency == undefined || !adframeConfig.dependency.length) {
    adframeConfig.dependency = "dependencies_stories_v1";
}
    Promise.all([
        loadScriptSync(deps + adframeConfig.dependency + '/vdo.min.js?v='+((typeof version === 'undefined') ? '' : version), "_vdo_ads_css_5654_"),
        loadScriptSync("//imasdk.googleapis.com/js/sdkloader/ima3.js", "_vdo_ads_sdk_5654_")
    ]).then(function() {
        callAdframe();
    }).catch(function (e) {
        if (e.target) {
            var msg = "error_" + (e.target.src.indexOf("vdo.min.js") >= 0 ? "vdo.min.js" : "ima3.js");
        } else {
            var msg = e;
        }
    
        logError(msg,"s-programmersought");
    })
}

  }
  function loadGptCompanion(parentDivId) {
    var device = adframeConfig.device;
      if (device == "tablet" || device == "high-end") device = "mobile";
      else if (device == "other" || device == "connected tv")
        device = "desktop";
    if (!adframeConfig.companionBanner ||
        (adframeConfig.companionBanner.gtr.include &&
          !adframeConfig.companionBanner.gtr.include.includes(
            adframeConfig.country
          )) ||
        (adframeConfig.companionBanner.gtr.exclude &&
          adframeConfig.companionBanner.gtr.exclude.includes(
            adframeConfig.country
          )) || adframeConfig.allowed !== 'true')
      return;
    
    var refreshInterval;
    adframeConfig.companionBanner.rgtr.forEach((item) => {
      if (item.geos.includes(adframeConfig.country))
        refreshInterval = item.time * 1000;
      return;
    });
    if (!refreshInterval) refreshInterval = 30000;
    let parentDiv = document.getElementById(adframeConfig.parent_div);
    if (parentDiv) {
      var availableWidth = parentDiv.clientWidth;
      var allSizes = [[300, 50], [320, 50], [468, 60], [728, 90], [320, 100], [300, 100], [970, 90]];
      var sizes = allSizes.filter(function (size) {
        if (size[0] <= availableWidth) {
          return true;
        }
        return false;
      });
      var slotName = "/26001828," + adframeConfig.google_mcm + "/z1_dfp_ron_display_companion_b_pre";
      if (adframeConfig.companionBanner && adframeConfig.companionBanner.google_mcm && adframeConfig.companionBanner.google_mcm.placement) {
        slotName = adframeConfig.companionBanner.google_mcm.placement;
      }
      if(adframeConfig.google_mcm_apac !== "") var slotNameApac = "/22100121508,"+ adframeConfig.google_mcm_apac +"/ellipsis_dfp_ron_display_companion_b_pre";
      window.vdo_companion_slot = slotName;
      if (sizes.length) {
        function refreshGptSlot() {
            if (typeof pbjs_vdo !== "undefined") {
              window.googletag.cmd.push(function () {
                pbjs_vdo.que.push(function () {
                  pbjs_vdo.setTargetingForGPTAsync();
                });
                window.googletag.pubads().refresh([window.vdoCompanionGptSlot]);
              });
            } else {
              window.googletag.pubads().refresh([window.vdoCompanionGptSlot]);
            }
            window.vdo_ai_.ads[adframeConfig.unitId].amazonHasAd = false;
          }
            
        let previousCompanionDiv = document.getElementById("vdo-banner-ad");
        let previousApacCompanionDiv = document.getElementById("vdo-banner-ad-apac");
        let companionAd = document.createElement("div");
        companionAd.id = "vdo-banner-ad";
        companionAd.style.order = "1";
        companionAd.style.textAlign = "center";
        companionAd.style.marginTop = "10px";
        parentDiv.insertAdjacentElement("afterend", companionAd);
        let companionAdApac = document.createElement("div");
        companionAdApac.id = "vdo-banner-ad-apac";
        companionAd.style.order = "1";
        companionAdApac.style.textAlign = "center";
        companionAdApac.style.marginTop = "0px";
        companionAd.insertAdjacentElement("afterend", companionAdApac);
        let gptScript = document.createElement("script");
        gptScript.async = true;
        gptScript.src = "https://securepubads.g.doubleclick.net/tag/js/gpt.js";
        if (!window.googletag || !window.googletag._loaded_) document.head.appendChild(gptScript);
        window.googletag = window.googletag || {
          cmd: [],
        };
        window.googletag.cmd = window.googletag.cmd || [];
        window.googletag.cmd.push(function () {
          if (previousCompanionDiv) {
            window.googletag.destroySlots([window.vdoCompanionGptSlot]);
            window.googletag.destroySlots([window.vdoCompanionGptSlotApac]);
            clearTimeout(window.vdoCompanionRefreshTimer);
            if(previousApacCompanionDiv) previousApacCompanionDiv.remove();
            previousCompanionDiv.remove();
          }
          window.vdoCompanionGptSlot = window.googletag.defineSlot(slotName,sizes,"vdo-banner-ad");
          window.vdoCompanionGptSlot &&
            window.vdoCompanionGptSlot
              .addService(window.googletag.pubads())
              .setTargeting("site", [adframeConfig.domain]);
            if (adframeConfig.companionBanner && adframeConfig.companionBanner.google_mcm && adframeConfig.companionBanner.google_mcm.upr) {
              window.vdoCompanionGptSlot && window.vdoCompanionGptSlot.setTargeting("upr", adframeConfig.companionBanner.google_mcm.upr);
            } else {
              window.vdoCompanionGptSlot && window.vdoCompanionGptSlot.setTargeting("upr", "GOPT");
            }
          window.googletag.pubads().set("page_url", window.location.href);
          window.googletag.enableServices();
        });
        window.googletag.cmd.push(function () {
          window.googletag.display("vdo-banner-ad");
          var timestamp = Date.now();
          if (window.googletag.pubads().isInitialLoadDisabled()) {
            refreshGptSlot();
          }
          var isCreativeViewable = false;
          if (!window.vdo_companion_event) {
            window.vdo_companion_event = true;
            window.vdo_companion_sizes = sizes;
            window.googletag.pubads().addEventListener("slotRequested", (event) => {
                if (event.slot.getAdUnitPath() === slotName || event.slot.getAdUnitPath() === slotNameApac) {
                    event.slot.clearTargeting()
                    if (adframeConfig.companionBanner && adframeConfig.companionBanner.google_mcm && adframeConfig.companionBanner.google_mcm.upr) {
                      window.vdoCompanionGptSlot && window.vdoCompanionGptSlot.setTargeting("upr", adframeConfig.companionBanner.google_mcm.upr);
                    } else {
                      window.vdoCompanionGptSlot && window.vdoCompanionGptSlot.setTargeting("upr", "GOPT");
                    }
                    timestamp = Date.now();
                }
            })
            window.googletag.pubads().addEventListener("slotRenderEnded", function (event) {
              if (event.slot.getAdUnitPath() === slotName || event.slot.getAdUnitPath() === slotNameApac) {
                var containsAd = !event.isEmpty;
                isCreativeViewable = false;
                let typeOfDfpAdrendered = event.slot.getHtml();
                var widthOfads, heightOfads;
                if (event.size && event.size[0]) {
                  if(event.size[0] > 1){
                    widthOfads = event.size[0];
                    heightOfads = event.size[1];
                  }else if(typeOfDfpAdrendered.includes("apstag.renderImp") && window.companionAmazonAdWidth && window.companionAmazonAdHeight){
                    widthOfads = parseInt(window.companionAmazonAdWidth);
                    heightOfads = parseInt(window.companionAmazonAdHeight);
                  } else if(typeOfDfpAdrendered.includes("pbjs") && window.companionPrebidAdWidth && window.companionPrebidAdHeight){
                    widthOfads = parseInt(window.companionPrebidAdWidth);
                    heightOfads = parseInt(window.companionPrebidAdHeight);
                  }

                  function adResponsive(companionAdDiv){
                    companionAdDiv.style.maxWidth = `${widthOfads}px`;
                    companionAdDiv.style.margin = "2px auto";
                    companionAdDiv.style.width = `${widthOfads}px`;
                    companionAdDiv.style.height = `${heightOfads}px`;
                    companionAdDiv.style.minWidth = `${widthOfads}px`;
                    companionAdDiv.style.minHeight = `${heightOfads}px`;
                    var childComponent =
                      companionAdDiv.getElementsByTagName("div")[0];
                    if (childComponent) {
                      childComponent.style.width = `${widthOfads}px`;
                      childComponent.style.height = `${heightOfads}px`;
                    }
                    var iframe = companionAdDiv.querySelector("iframe");
                    if (iframe) {
                      iframe.style.width = widthOfads + "px";
                      iframe.style.height = heightOfads + "px";
                    }
                  }
                  let companionAdDiv = document.getElementById("vdo-banner-ad");
                  if (companionAdDiv && event.slot.getAdUnitPath() === slotName) {
                    adResponsive(companionAdDiv);
                  }else if(companionAdApac && event.slot.getAdUnitPath() === slotNameApac){
                    adResponsive(companionAdApac);
                  }
                }
                if (containsAd) {
                  if(event.slot.getAdUnitPath() === slotNameApac){
                    window.vdoCompanionRefreshTimer = setTimeout(function () {
                      window.googletag.destroySlots([window.vdoCompanionGptSlotApac]);
                      companionAdApac.style.minHeight =  "0px";
                      companionAdApac.style.height =  "0px";
                      window.googletag.pubads().set("page_url", window.location.href);
                      isCreativeViewable = false;
                      refreshGptSlot();
                    }, refreshInterval);
                  }
                } else if(adframeConfig.google_mcm_apac == "" || event.slot.getAdUnitPath() === slotNameApac || adframeConfig.country != "US"){
                    window.googletag.destroySlots([window.vdoCompanionGptSlotApac]);
                    companionAdApac.style.minHeight =  "0px";
                    companionAdApac.style.height =  "0px";
                    window.vdoCompanionRefreshTimer = setTimeout(function () {
                      isCreativeViewable = false;
                      refreshGptSlot();
                    }, refreshInterval);
                } else{
                  companionAd.style.minHeight =  "0px";
                  companionAd.style.height =  "0px";
                  window.googletag.cmd.push(function () {
                    window.googletag.destroySlots([window.vdoCompanionGptSlotApac]);
                    window.googletag.pubads().clear([window.vdoCompanionGptSlot]);
                    window.vdoCompanionGptSlotApac = window.googletag
                      .defineSlot(slotNameApac,sizes,"vdo-banner-ad-apac")
                      .setCollapseEmptyDiv(false)
                      .addService(window.googletag.pubads())
                      .setTargeting("site", [adframeConfig.domain]);
                      window.googletag.pubads().set("page_url", window.location.href);
                      window.googletag.enableServices();
                      window.googletag.display("vdo-banner-ad-apac");
                    if(window.googletag.pubads().isInitialLoadDisabled()) window.googletag.pubads().refresh([window.vdoCompanionGptSlotApac]);
                  });
                }
              }
            });
            window.googletag.pubads().addEventListener("slotVisibilityChanged", function (event) {
              if (event.slot.getAdUnitPath() === slotName && !isCreativeViewable) {
                var timeFromRender = Date.now() - timestamp;
                if (event.inViewPercentage >= 50) {
                  isCreativeViewable = true;
                  if (timeFromRender >= refreshInterval) {
                    window.vdoCompanionRefreshTimer = setTimeout(function () {
                      refreshGptSlot();
                    }, 1000);
                  } else {
                    window.vdoCompanionRefreshTimer = setTimeout(function () {
                      refreshGptSlot();
                    }, refreshInterval - timeFromRender);
                  }
                }
              }
            });
          }
        });
      }
    }
  }

  function changeParentDivId(){
    window.vdo_ai_ = window.vdo_ai_ || {};
    window.vdo_ai_.ads = window.vdo_ai_.ads || {};
    window.vdo_ai_.ads[adframeConfig.unitId]  = window.vdo_ai_.ads[adframeConfig.unitId] || {}
    window.vdo_ai_.ads[adframeConfig.unitId].amazonHasAd = false;
    window.vdo_ai_.ids = window.vdo_ai_.ids || [];
    var parent = document.getElementById(adframeConfig.parent_div);
    adframeConfig.parent_div = adframeConfig.parent_div+"-"+window.vdo_ai_.ids.length;
    parent.id = adframeConfig.parent_div;
    window.vdo_ai_.ids.push({
      parentId: adframeConfig.parent_div,
    })
  }

  

  var current_url = location.host + location.pathname;
  current_url = current_url.replace(/(\/*)$/, '').replace(/^(?:https?:\/\/)?(?:www\.)?/i, "");
  var failsafeCheck = false;
  
  var oReq = new XMLHttpRequest();
  oReq.onload = function() {    vdo_analytics('event', 'timing_complete', {
      name: 'load_allowed_url.php',
      value: Date.now() - allowedUrlTimestamp,
      event_category: 'stories',
      send_to: vdo_analyticsID,
      event_label: "s-programmersought",
    });    try {
    if(!failsafeCheck) {
      failsafeCheck = true;
      clearTimeout(failsafeTimeout);
      var response = JSON.parse(this.response);

      if(response.agent=="false"){
        
          adframeConfig = Object.assign(adframeConfig, response);
          if(typeof custom_feed_url !== 'undefined'){
            var feedReq = new XMLHttpRequest();
            feedReq.onerror = function() { 
              startTag(adframeConfig.ver);
            }
            feedReq.onload = function() { 
              try{

                var feedResponse = JSON.parse(this.response);
                console.log(feedResponse)
                adframeConfig = Object.assign(adframeConfig, feedResponse);
              
              }catch(r){
              
              }
              startTag(adframeConfig.ver);
            }.bind(feedReq);
            feedReq.open('get', '//a.vdo.ai/core/s-programmersought/dynamic_feed?feed_url=' + encodeURIComponent(custom_feed_url), true);
            feedReq.send();  
          }
          else{
            startTag(adframeConfig.ver);
          }
    

      }
      else{
        var requestObject = {
          domainName: location.hostname,
          page_url:location.href,
          tagName: 's-programmersought',
          event: 'blocked_agent',
          eventData: 1,
          uid: ''
        };

        logPixel(requestObject);        vdo_analytics('event', 'blocked_agent', { send_to: vdo_analyticsID, event_category: 'vdoaijs', event_label: 's-programmersought' });
      }
    }else{
      var response = JSON.parse(this.response);
      window[response.unitId + "_vast"] = response.vast;
    }
  } catch (e) {
    logError(e,'s-programmersought');
  }
}.bind(oReq);

    let statusCode = null;
  let duration = null;
  let singleRunFlag = false;

  function logAllowedUrlTiming(){
    if(!duration || !statusCode || singleRunFlag) return
    vdo_analytics('event','timing_complete', {
        name: `allowed_url_response_${statusCode}`,
        value: duration,
        event_category: 'video',
        send_to: vdo_analyticsID,
        event_label: 's-programmersought',
      });
      singleRunFlag = true;
  }

  const po = new PerformanceObserver((list) => {
    for (const entry of list.getEntries()) {
      if(entry.name.match('vdo.ai/allowed_url.php')){
        duration = entry.duration;
        logAllowedUrlTiming();
      }
    }
  });
  po.observe({type: 'resource', buffered: true});
  oReq.onreadystatechange = () => {
    if (oReq.readyState === XMLHttpRequest.DONE) {
      statusCode = oReq.status;
      logAllowedUrlTiming();
    }
  }

  oReq.open("post", "https://targeting.vdo.ai/allowed_url.php?type=json&url=" + encodeURIComponent(current_url) + "&mul_type=os+wb&tag=s-programmersought&domain=" + adframeConfig.domain, true);
  var allowedUrlTimestamp = Date.now();
  oReq.send();

  var failsafeTimeout = setTimeout(function() {
    if(!failsafeCheck) {
      failsafeCheck = true;
      var response = {"allowed":"true","agent":"false","ip_address":"null","country":"unknown"}; // Hardcoded default response in case of call takes more than 3seconds
      adframeConfig = Object.assign(adframeConfig, response);
      resolve(adframeConfig.ver);
    }
  }, 3000);
  




//#endregion

})(w_vdo, d_vdo, '//a.vdo.ai/core/', 's-programmersought');

} catch (e) {
  logError(e,'s-programmersought');
}